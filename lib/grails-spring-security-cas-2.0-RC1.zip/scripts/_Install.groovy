println '''
*****************************************************
* You've installed the Spring Security CAS plugin.  *
*                                                   *
* Be sure to configure required attributes in       *
* grails-app/conf/Config.groovy before running your *
* application.                                      *
*                                                   *
*****************************************************
'''
